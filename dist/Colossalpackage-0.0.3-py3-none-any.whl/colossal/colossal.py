def hello():
    print('Hello Colossal')